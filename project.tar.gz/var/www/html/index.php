<?php
header("Location: /landing-page/");
?>
