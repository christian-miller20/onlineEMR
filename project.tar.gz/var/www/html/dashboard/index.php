<?php
session_start();

if (!isset($_SESSION["username"])) {
	header("Location: http://3.95.80.50:8005/");
        exit;
}
?>

<!doctype html><html lang="en"><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/><meta name="theme-color" content="#000000"/><title>Dashboard Page</title><script defer="defer" src="/dashboard/static/js/main.01a21a68.js"></script><link href="/dashboard/static/css/main.97b9d0c1.css" rel="stylesheet"></head><body><div id="root"></div></body></html>
