<?php
session_start();

if (!isset($_SESSION["username"])) {
        header("Location: http://3.95.80.50:8005/");
        exit;
}
?>

<!doctype html><html lang="en"><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/><meta name="theme-color" content="#000000"/><title>Add Patient</title><script defer="defer" src="/newpatientchart/static/js/main.b667bfa4.js"></script><link href="/newpatientchart/static/css/main.11f63993.css" rel="stylesheet"></head><body><div id="root"></div></body></html>
