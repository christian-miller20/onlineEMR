<?php
session_start();

if (!isset($_SESSION["username"])) {
        header("Location: http://3.95.80.50:8005/");
        exit;
}
?>

<!doctype html><html lang="en"><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/><meta name="theme-color" content="#000000"/><title>Settings Page</title><script defer="defer" src="/settings/static/js/main.3a0019c6.js"></script><link href="/settings/static/css/main.2a887108.css" rel="stylesheet"></head><body><div id="root"></div></body></html>
