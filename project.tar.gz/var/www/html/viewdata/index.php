<?php
session_start();

if (!isset($_SESSION["username"])) {
        header("Location: http://3.95.80.50:8005/");
        exit;
}
?>

<!doctype html><html lang="en"><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/><meta name="theme-color" content="#000000"/><title>View Data Page</title><script defer="defer" src="/viewdata/static/js/main.9c0daaf5.js"></script><link href="/viewdata/static/css/main.4cfd79b2.css" rel="stylesheet"></head><body><div id="root"></div></body></html>
